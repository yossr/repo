data = {};
Filtre = {};


data.umlClasses = [];
data.umlLinks = [];
tabElements = [];
var globalCurrentObj;

function setLocalStorageXMI(xmi){
	localStorage.setItem('histoXMI',xmi);
	console.log(xmi);
}

function geneHistoXMI(){
		if('histoXMI' in localStorage){
			var histoXMIRecup = localStorage.getItem('histoXMI');
			traiterXMI(histoXMIRecup);
		}
		else{
		}
	
}


function addAgregation (container, contained, leftLabel, rightLabel) {
    data.umlLinks.push({from:container.key, to:contained.key,left:leftLabel,right:rightLabel,category:"agregation"});
}

function addAssociation (leftElement, rightElement, leftLabel, rightLabel) {
    data.umlLinks.push({from:leftElement.key, to:rightElement.key,left:leftLabel,right:rightLabel,category:"association"});
}

function addComposition (container, contained, leftLabel, rightLabel) {
    data.umlLinks.push({from:container.key, to:contained.key,left:leftLabel,right:rightLabel,category:"composition"});
}

function addUmlClasses (tab) {
    for (var i=0;i<tab.length;i++) {
    	if(tab[i].category == "umlClass"){
    		for(var j=0;j<tab.length;j++){
        		if(tab[i].idParent == tab[j].key){
        			tab[i].setGroup(tab[j].key);
        		}
        	}
        	data.umlClasses.push(tab[i].finalParse());	
        }
        else if(tab[i].category == "umlPackage"){
        	data.umlClasses.push(tab[i].finalParse());}
    }
    diagram.model.addNodeData(data.umlClasses[0]);
    for(var j=0;j<data.umlClasses.length;j++){
    	diagram.model.addNodeData(data.umlClasses[j]);}
    for(var k=0;k<data.umlLinks.length;k++){
    	diagram.model.addLinkData(data.umlLinks[k]);}
}

function traiterXMI(xmi){
	code = jQuery.parseXML(xmi);
	jQuery(code).find("packagedElement").each(function(index,el){
		if(isPrimitiveType(el)){
			getPrimitiveTypeAndAdd(el);
		}
	})
	jQuery(code).find("*").each(function(index, el){
		if(isPackage(el)){
			getPackageAndAdd(el);
		}
		else if(isClass(el)){
			getClassAndAdd(el);
		}

		else if(isAttribute(el)) {
			getAttributeAndAdd(el);
		}

		else if(isMethod(el)){
			getMethodAndAdd(el);
		}
		else if (isParameter(el)){
			getParameterAndAdd(el);
		}
	});	
	
	addAttributeToAppropriateClass();
	addMethodToAppropriateClass();
	jQuery(code).find("packagedElement").each(function(index, el){
		traiterRelations(index,el,code);	
	});
	addUmlClasses(tabElements);
}

function getLvlParent(id, el){
	var lvl;
	for (var e=0; e<tabElements.length;e++){
		console.log(tabElements[e].idEnfant);
			if (tabElements[e].idEnfant==id) {
				tabElements[e].idEnfant.push(el.getAttribute("xmi:id"));
				lvl = tabElements[e].level;}}
		return lvl;
}

//Fonctions de test de présence
function isPackage(element){
	return (element.getAttribute("xmi:type")==="uml:Package");
}
function isClass(element){
   	return (element.getAttribute("xmi:type")==="uml:Class");
}
function isAttribute(element){
	var attr = jQuery(element).attr('aggregation');
	var asso = jQuery(element).attr('association');
	return((element.getAttribute("xmi:type") === "uml:Property") && ((typeof attr === typeof undefined || attr === false) && (typeof asso === typeof undefined || asso === false)));
}
function isPrimitiveType(element){
	return((element.getAttribute("xmi:type") === "uml:PrimitiveType"));
}
function isMethod(element){
	return (element.getAttribute("xmi:type")==="uml:Operation");
}
function isParameter(element){
	return (element.getAttribute("xmi:type")==="uml:Parameter");
}
function isRelation(element){
	return (element.getAttribute("xmi:type")==="uml:Association");
}
function isAggregation(element){
	var attr = jQuery(element).attr('aggregation');
	return(jQuery(element).attr("xmi:type") === "uml:Property") && (!(typeof attr === typeof undefined || attr === false));
}
function isAssociation(element){
	var asso = jQuery(element).attr('association');
	var attr = jQuery(element).attr('aggregation');
	return((jQuery(element).attr("xmi:type") === "uml:Property") && (!(typeof asso === typeof undefined || asso === false) && (typeof attr === typeof undefined || attr === false)));
}

function getClassAttributes(classe){
    var tmp = jQuery(classe).find("ownedAttribute");
	return tmp;
}

function getClassMethods(classe){
	var tmp = jQuery(classe).find("ownedOperation");
	return tmp;
}
