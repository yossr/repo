function saveDiagram() {
	jsonDiag = diagram.model.toJson();

	var div = document.getElementById("menu");
	var input = document.createElement("textarea");
	input.rows = "4";
	input.cols = "25";
	div.appendChild(input); //appendChild
	input.value = jsonDiag;
}

function importDiagJson(textjSon){
	alert("gene");
	diagram.model = go.Model.fromJson(textjSon);
}