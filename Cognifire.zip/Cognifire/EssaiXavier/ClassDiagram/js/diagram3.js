
var $ = go.GraphObject.make;
var diagram = $(go.Diagram,"ClassDiagramDiv",
    {
        initialContentAlignment : go.Spot.Center,
        "undoManager.isEnabled" : true
    }
);
var objTemp2;
var criteria="";
var classSelected = false;
var debut=0;
var classNumber=6;
var attributesVisibility=0;
var forelayer = diagram.findLayer("Foreground");
diagram.addLayerBefore($(go.Layer, { name: "red" }), forelayer);
diagram.addLayerBefore($(go.Layer, { name: "blue" }), forelayer);
diagram.addLayerBefore($(go.Layer, { name: "green" }), forelayer);
umlClassTemplate =
    $ (go.Node,"Auto", 
        {
        click: function(e, obj) {
            var errPriorDiff = document.getElementById("errPriorDiff");
            try{   
                if(classSelected == true){
                    //A traiter
                    divpNameClass = document.getElementById("nameClass");
                    divpNameClass.innerHTML = obj.part.data.name;
                    divAttributes = document.getElementById("numAttr");
                    divAttributes.innerHTML = "Nombre d'attributs : " + obj.part.data.attributes.length;
                    divOperations = document.getElementById("numOpe");
                    divOperations.innerHTML = "Nombre d'opérations : " + obj.part.data.operations.length;
                }
                else{
                    console.log("yoyo")
                    divClass = document.createElement("div");
                    var pNameClass;
                    document.getElementById("infos").appendChild(divClass);
                    jQuery(divClassSelected).find("p").each(function(index,el){
                        console.log("yoyoyoyo")
                        if(el.getAttribute("id") == "nameClass"){
                            pNameClass = el;
                        }
                    });
                    pNameClass.innerHTML = obj.part.data.name;
                    divAttributes = document.createElement("p");
                    divAttributes.setAttribute("id","numAttr");
                    divAttributes.innerHTML = "Nombre d'attributs : " + obj.part.data.attributes.length;
                    divOperations = document.createElement("p");
                    divOperations.setAttribute("id","numOpe");
                    divOperations.innerHTML = "Nombre d'opérations : " + obj.part.data.operations.length;
                    divClass.appendChild(divAttributes);
                    divClass.appendChild(divOperations);
                    classSelected = true;
                    // A finir pour afficher les attributs et les méthodes
            }
                if(criteria!=""){
                        criteria = "";
                        cara = 0;
                        var formerSelectedCase = document.getElementById("selected");
                        if(formerSelectedCase!= null || formerSelectedCase!= undefined){
                            formerSelectedCase.removeAttribute("id");
                        }
                        console.log(globalCurrentObj.part.data);
                        console.log(classSelected);
                        
                }
                else{
                    

                }
            }
            catch(err){
                    //document.getElementById("errPriorDiff").innerHTML = "<p>"+err+"</p>";
            }

        },
        /*selectionChanged: function(part) {
            
            var shape = part.elt(0);
            shape.fill = part.isSelected ? "red" : "white";
          }*/
      },
        new go.Binding("angle", "", function (x) {return UmlClassStrategy.angle(x);}),
        new go.Binding("layerName", "color"),
        $(go.Shape,"Rectangle",{ isPanelMain : true},
           // new go.Binding("fill", "color"),
            new go.Binding("fill", "", function (x) {if (debut<classNumber) {debut++;return x.color} else {return UmlClassStrategy.bgColor(x);}}),
            new go.Binding("stroke", "", function (x) {return UmlClassStrategy.borderColor(x);}),
            new go.Binding("strokeWidth", "", function (x) {return UmlClassStrategy.borderWidth(x);})
            ),
        $(go.Panel, "Vertical",
            $(go.TextBlock, "ClassName",
                { margin : 8, editable: true},
                new go.Binding("isUnderline", "", function (x) {return UmlClassStrategy.isUnderline(x)}),
                new go.Binding("stroke", "", function (x) {return UmlClassStrategy.textColor(x);}),
                new go.Binding("font", "", function (x) {return UmlClassStrategy.textStyle(x);}),
                new go.Binding("text","name")),
            $(go.Shape, "LineH",
                {height : 2, stretch : go.GraphObject.Fill},
                    new go.Binding("stroke", "", function (x) {return UmlClassStrategy.lineColor(x);}),
                    //new go.Binding("strokeWidth", "", function (x) {return UmlClassStrategy.borderWidth(x);}),
                    new go.Binding("strokeWidth", "", function (x) {return UmlClassStrategy.borderLineWidth(x);})
            ),
            $(go.Panel, "Vertical",
                {stretch : go.GraphObject.Fill},
                new go.Binding("itemArray", "attributes"),
                {
                    defaultAlignment: go.Spot.Left,
                    itemTemplate:
                        $(go.Panel, "Auto",
                            { margin: 2 },
                            $(go.TextBlock, { margin : 8, stroke : "black", font : " 11px sans-serif"},
                                new go.Binding("visible", "", function (v) {console.log(UmlClassStrategy.attributesVisiblity);return UmlClassStrategy.attributesVisiblity}),
                                new go.Binding("stroke", "", function (v) {console.log(UmlClassStrategy.attributesColor);return UmlClassStrategy.attributesColor}),
                                new go.Binding("font", "", function (v) {console.log(UmlClassStrategy.attributesTextStyle);return UmlClassStrategy.attributesTextStyle}),
                                new go.Binding("text", "", function (v) {return v.type+" "+ v.name}),
                                { margin: 2})
                        )  // end of itemTemplate
                }),
            $(go.Shape, "LineH",
                {height : 2, stretch : go.GraphObject.Fill},
                    new go.Binding("stroke", "", function (x) {return UmlClassStrategy.borderColor(x);}),
                    new go.Binding("stroke", "", function (x) {return UmlClassStrategy.lineColor(x);}),
                    new go.Binding("strokeWidth", "", function (x) {return UmlClassStrategy.borderLineWidth(x);})
            ),
            $(go.Panel, "Vertical",
                new go.Binding("itemArray", "operations"),
                {
                    defaultAlignment: go.Spot.Left,
                    itemTemplate:
                        $(go.Panel, "Auto",
                            { margin: 2 },
                            $(go.TextBlock, { margin : 8},
                                new go.Binding("visible", "", function (v) {console.log(UmlClassStrategy.operationsVisiblity);return UmlClassStrategy.operationsVisiblity}),
                                new go.Binding("stroke", "", function (v) {console.log(UmlClassStrategy.operationsColor);return UmlClassStrategy.operationsColor}),
                                new go.Binding("font", "", function (v) {console.log(UmlClassStrategy.operationsTextStyle);return UmlClassStrategy.operationsTextStyle}),
                                new go.Binding("text", "",
                                    function (v) {
                                        var parameters="";
                                        var first = true;
                                        for (p in v.parameters) {
                                            parameters+=(first?"":", ")+v.parameters[p].type+ " "+v.parameters[p].name+" ";
                                            first=false;
                                        }
                                        return v.returnType+" "+ v.name+"("+parameters+")";
                                    }),
                                { margin: 2 })
                        )  // end of itemTemplate
                })
        )
    );

umlPackageTemplate =
    $(go.Group, "Vertical",
        $(go.Panel, "Vertical",{defaultAlignment: go.Spot.Left},
            $(go.Panel, "Auto",
                $(go.Shape, "Rectangle",
                    { parameter1: 14,
                        fill: "rgba(128,128,128,0.33)" }),
                $(go.TextBlock, "PackageName",
                    { margin : 8, stroke : "black", font : "bold 11px sans-serif"},
                    new go.Binding("text","key"))
            ),
            $(go.Panel, "Auto",
                $(go.Shape, "Rectangle",  // surrounds the Placeholder
                    { parameter1: 14,
                        fill: "rgba(128,128,128,0.33)" }),
                $(go.Placeholder,    // represents the area of all member parts,
                    { padding: 5})  // with some extra padding around them
            )
        )
    );

var templatesMap = new go.Map("string", go.Part);
templatesMap.add("umlClass", umlClassTemplate);
templatesMap.add("", diagram.nodeTemplate);
diagram.nodeTemplateMap = templatesMap;


var groupTemplatesMap = new go.Map("string", go.Group);
groupTemplatesMap.add("umlPackage", umlPackageTemplate);
groupTemplatesMap.add("", diagram.groupTemplate);
diagram.groupTemplateMap = groupTemplatesMap;

association =
    $(go.Link, {routing: go.Link.AvoidsNodes},
        $(go.Shape),
        $(go.TextBlock, { segmentIndex: 0, segmentFraction: 0.2 }, new go.Binding("text", "left")),
        $(go.TextBlock, { segmentIndex: 0, segmentFraction: 0.5 }, new go.Binding("text", "mid")),
        $(go.TextBlock, { segmentIndex: 0, segmentFraction: 0.8 }, new go.Binding("text", "right"))
    );


agregation = $(go.Link, {routing: go.Link.AvoidsNodes},
    $(go.Shape),
    $(go.Shape, { fromArrow: "Diamond" , fill:"white"}),
    $(go.TextBlock, { segmentIndex: 0, segmentFraction: 0.2 }, new go.Binding("text", "left")),
    $(go.TextBlock, { segmentIndex: 0, segmentFraction: 0.5 }, new go.Binding("text", "mid")),
    $(go.TextBlock, { segmentIndex: 0, segmentFraction: 0.8 }, new go.Binding("text", "right"))
);

composition = $(go.Link, {routing: go.Link.AvoidsNodes},
    $(go.Shape),
    $(go.Shape, { fromArrow: "Diamond" , fill:"black"}),
    $(go.TextBlock, { segmentIndex: 0, segmentFraction: 0.2 }, new go.Binding("text", "left")),
    $(go.TextBlock, { segmentIndex: 0, segmentFraction: 0.5 }, new go.Binding("text", "mid")),
    $(go.TextBlock, { segmentIndex: 0, segmentFraction: 0.8 }, new go.Binding("text", "right"))
);

var linkTemplatesMap = new go.Map("string", go.Link);
linkTemplatesMap.add("association", association);
linkTemplatesMap.add("agregation", agregation);
linkTemplatesMap.add("composition", composition);
linkTemplatesMap.add("", diagram.linkTemplate);
diagram.linkTemplateMap = linkTemplatesMap;

diagram.addDiagramListener("ChangedSelection",
    function(e) {
        if(diagram.selection.count == 0){
            document.isPartSelected = false;
        }
        else{
            document.isPartSelected = true;
        }
        ;
    }
);

//customer.group="Omega";
//customer.category="umlClass";

var nodeDataArray = data.umlClasses;
var linkDataArray = data.umlLinks;
function callAddAssociateToProperty(bouton){
    priority = bouton.getAttribute("id");
    console.log(priority);
    criteria = priority;
    /*if(document.getElementById('priorityRadio-btn').checked){
        criteria="priority";
    }else if(document.getElementById('difficultyRadio-btn').checked){
        criteria="difficulty"
    }
    else if(document.getElementById('auteurRadio-btn').checked){
        criteria="auteur";
    }
    */

}
toggleVisible = function(layername, e) {
    var layer = diagram.findLayer(layername);
    if (layer !== null) layer.visible = e.checked;
};

 setVisibility = function(v){
     if(v.visibility=='private'){UmlClassStrategy.visible=true;}
     else {UmlClassStrategy.visible=false}
     DecorateDiagram.updateDiagramTemplates();
 }


    /*[
    customer,
    { key: "Alpha" },
    { key: "Beta", group: "Omega" },
    { key: "Gamma", group: "Omega" },
    { key: "Omega", isGroup: true, category : "umlPackage" },
    { key: "Delta" }
];*/
/*
var linkDataArray = [
    { from: "Alpha", to: "Beta" },  // from outside the Group to inside it
    { from: "Beta", to: "Gamma" },  // this link is a member of the Group
    { from: "Omega", to: "Delta" }  // from the Group to a Node
];*/
diagram.model = new go.GraphLinksModel(nodeDataArray, linkDataArray);
window.diagram = diagram;


