function addRelationToDiagram(typeRelationLeft,typeRelationRight,classLeft,classRight,stringLeft,stringRight){
    console.log("typeRelationLeft : " + typeRelationLeft);
    console.log("typeRelationRight : " + typeRelationRight);
    if(!(typeRelationLeft==="association") || !(typeRelationRight === "association")){
            if((typeRelationLeft==="shared") || (typeRelationRight === "shared")){
                addAgregation(classLeft,classRight,stringLeft,stringRight);
                console.log("Ajout d'une relation de type aggregation");}
            else{
                addComposition(classLeft,classRight,stringLeft,stringRight);
                console.log("Ajout d'une relation de type composition");}}
        else{
            addAssociation(classLeft,classRight,stringLeft,stringRight);
            console.log("Ajout d'une relation de type association");}
}

function getLeftAssociatedClass(typeLeftElement,classLeft){
    for(var i=0 ;i< tabElements.length;i++){
        if(tabElements[i].key === typeLeftElement){
            classLeft = tabElements[i];}}
    return classLeft;
}

function getRightAssociatedClass(typeRightElement,classRight){
        for(var j=0 ;j< tabElements.length;j++){
            if(tabElements[j].key === typeRightElement){
                classRight = tabElements[j];}}
        return classRight;
}

function setRightLabel(transitRight,cardRight){
    return transitRight + " " +cardRight;
}

function getRightCardinalite(el,el2,cardRight){
    //Recuperation des labels à afficher sur la relation
    if(jQuery(el2).attr("aggregation")){
        transitRight = jQuery(el2).attr("name");}
    if(el2.firstChild){
        if((jQuery(el2).find("lowerValue").attr("value")) && (jQuery(el2).find("upperValue").attr("value"))){
            cardRight = cardRight + jQuery(el2).find("lowerValue").attr("value");
            cardRight = cardRight + ".." +  jQuery(el2).find("upperValue").attr("value");}
        else if(!(jQuery(el2).find("lowerValue").attr("value")) && (jQuery(el2).find("upperValue").attr("value"))){
            cardRight = "0.." +  jQuery(el2).find("upperValue").attr("value");}
        else if(!(jQuery(el2).find("lowerValue").attr("value")) && !(jQuery(el2).find("upperValue").attr("value"))){
            cardRight = "0";
        }
    }
    return cardRight;
}

function getRightRelationType(el2){
    if(isAssociation(el2)){// test si le second attribut est indique une association
        typeRelationRight = "association";}
    else if (isAggregation(el2)){// test si le second attribut est indique une aggregation
        typeRelationRight = jQuery(el2).attr("aggregation");}
    return typeRelationRight;
}

function setLeftLabel(transitLeft,cardLeft){
    return transitLeft + " " + cardLeft;
}

function getLeftCardinalite(el,el1,cardLeft){
    //Recuperation des labels à afficher sur la relation 
    if(jQuery(el).attr("aggregation")){
        transitLeft = jQuery(el1).attr("name");}
    if(el1.firstChild){
        if((jQuery(el1).find("lowerValue").attr("value")) && (jQuery(el1).find("upperValue").attr("value"))){
            cardLeft = cardLeft + jQuery(el1).find("lowerValue").attr("value");
            cardLeft = cardLeft + ".." +  jQuery(el1).find("upperValue").attr("value");}
        else if(!(jQuery(el1).find("lowerValue").attr("value")) && (jQuery(el1).find("upperValue").attr("value"))){
            cardLeft = "0.." +  jQuery(el1).find("upperValue").attr("value");}
        else if(!(jQuery(el1).find("lowerValue").attr("value")) && !(jQuery(el1).find("upperValue").attr("value"))){
            cardRight = "0";
        }}
    return cardLeft;
}

function getLeftRelationType(el1){
    if(isAssociation(el1)){// test si le premier attribut est indique une association
        typeRelationLeft = "association";
    }
    else if (isAggregation(el1)){// test si le premier attribut est indique une aggregation
        typeRelationLeft = jQuery(el1).attr("aggregation"); 
    }
    return typeRelationLeft;
}

function traiterRelations(index, el,code){

	if(isRelation(el)){
		//Initialisation des variables pour récuperer les classes et les labels associés à cette relation
		var typeRelationLeft;
		var typeRelationRight;
		var typeRelation;
		var memberEnd = jQuery(el).attr("memberEnd"); // les deux id correspondants aux classes associées
		var pos = memberEnd.indexOf(" ");
    	var idLeftElement = memberEnd.slice(0,pos);
    	var typeLeftElement;
    	var typeRightElement;
    	var cardLeft = ""; //Cardinalité affichée sur la classe de gauche
    	var cardRight = ""; //Cardinalité affichée sur la classe de droite
    	var transitRight = ""; //Variable transitive affichée sur la classe de gauche
    	var transitLeft = ""; //Variable transitive affichée sur la classe de droite
    	var stringLeft = ""; // Concatenation des variables cardLeft et transitLeft qui sera affichée sur le diagramme sur la classe de gauche
    	var stringRight = ""; // Concatenation des variables cardLeft et transitLeft qui sera affichée sur le diagramme sur la classe de droite
    	jQuery(code).find("*").each(function(index, el1){
    		if(jQuery(el1).attr("xmi:id")===idLeftElement){
    			typeRelationLeft = getLeftRelationType(el1);
                cardLeft = getLeftCardinalite(el,el1,cardLeft);
    			typeLeftElement = jQuery(el1).attr("type");
    			stringLeft = setLeftLabel(transitLeft,cardLeft);
                console.log("typeLeft : " + typeRelationLeft)
            }});
    	var idRightElement = memberEnd.slice(pos+1,memberEnd.length);
    	jQuery(code).find("*").each(function(index, el2){
    		if(jQuery(el2).attr("xmi:id")===idRightElement){
    			typeRelationRight = getRightRelationType(el2);
    			cardRight =  getRightCardinalite(el,el2,cardRight);
    			typeRightElement = jQuery(el2).attr("type");
    			stringRight = setRightLabel(transitRight,cardRight);
                console.log("typeRight : " + typeRelationRight)


            }});
        //Recuperation des classes associées
		var classLeft = getLeftAssociatedClass(typeLeftElement,classLeft);
		var classRight = getRightAssociatedClass(typeRightElement,classRight);
        console.log("classLeft : ");
        console.log(classLeft);
        console.log("classRight : ");
        console.log(classRight)
        addRelationToDiagram(typeRelationLeft,typeRelationRight,classLeft,classRight,stringLeft,stringRight);
    }
}