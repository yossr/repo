function getPackageAndAdd(el){
	if(jQuery(el).parent().attr("name")=="RootElement"){
		var pack = new Package(el.getAttribute("xmi:id"),el.getAttribute("name"), 0, 0);
		tabElements.push(pack);
	}
	else{
		idParent = jQuery(el).parent().attr("xmi:id");
		var pack = new Package(el.getAttribute("xmi:id"),el.getAttribute("name"), idParent);
		tabElements.push(pack);
	}
}

function getClassAndAdd(el){
	if(jQuery(el).parent().attr("name")=="RootElement"){
		var classe = new Classe(el.getAttribute("xmi:id"),el.getAttribute("name"), 0,el.getAttribute("visibility"));
		tabElements.push(classe);}
	else{
		idParent = jQuery(el).parent().attr("xmi:id");
		var classe = new Classe(el.getAttribute("xmi:id"),el.getAttribute("name"), idParent,el.getAttribute("visibility"));
		tabElements.push(classe);}
}

function getAttributeAndAdd(el){
	if(el.firstChild){
		idParent = jQuery(el).parent().attr("xmi:id");
		idCurrAttribute = el.getAttribute("xmi:id");
		var attribute = new Attribute(idCurrAttribute,el.getAttribute("name"), idParent,el.getAttribute("visibility"),getPrimitiveType(el)); /* TRAITEMENT POUR RECUPERER LE TYPE ET L'AJOUTER À L'OBJET */
		tabElements.push(attribute);}
	else{
		idParent = jQuery(el).parent().attr("xmi:id");
		idCurrAttribute = el.getAttribute("xmi:id");
		var attribute = new Attribute(idCurrAttribute,el.getAttribute("name"), idParent,el.getAttribute("visibility"),getPrimitiveType(el)); /* TRAITEMENT POUR RECUPERER LE TYPE ET L'AJOUTER À L'OBJET */
		tabElements.push(attribute);}
}

function getMethodAndAdd(el){
	idParent = jQuery(el).parent().attr("xmi:id");
	idCurrMethod = el.getAttribute("xmi:id");
	var method = new Operation(idCurrMethod,el.getAttribute("name"),idParent);
	tabElements.push(method);
}

function getParameterAndAdd(el){
	idParent = jQuery(el).parent().attr("xmi:id");
	idPrimitive = jQuery(el).attr("type");
	name = jQuery(el).attr("name");
	type = getPrimitiveType(el);
		for (var i=0;i<tabElements.length;i++){
			if(tabElements[i].key === idParent){
				tabElements[i].addParam(name,type);}}
}

function getPrimitiveType(el){
	var returnType;
	elType = jQuery(el).attr("type");
	elChildType = jQuery(el).find("type").attr("href");

	tabTypes = ["string","int","integer","double","float","boolean","date","datetime","long","short","char"];

	if((elType)&& !(elChildType)){
		for(i=0;i<tabElements.length;i++){
			if(tabElements[i].category == "uml:PrimitiveType"){
				returnType = tabElements[i].name;
			}
		}
	}
	else if(!(elType)&&(elChildType)){
		elChildType = elChildType.toLowerCase();
		for(var i=0;i<tabTypes.length;i++){
			if(!(elChildType.indexOf(tabTypes[i])==-1)){
				returnType = tabTypes[i];
			}
		}
	}

	return returnType;
}

function getPrimitiveTypeAndAdd(el){
	if(el.getAttribute("xmi:type") && !(el.getAttribute("href"))){
		var primitive = new PrimitiveType(el.getAttribute("xmi:type"),el.getAttribute("xmi:id"),el.getAttribute("name"));
		tabElements.push(primitive);
	}
}


function addAttributeToAppropriateClass(){
	for(var o = 0;o<tabElements.length;o++){
		if(tabElements[o].category === "umlAttribute"){
			idParentAttr = tabElements[o].idParent;
				for(var k = 0;k<tabElements.length;k++){
					if(idParentAttr === tabElements[k].key){
						tabElements[k].attributes.push(tabElements[o].finalParse());}}}}
}

function addMethodToAppropriateClass(){
	for(var o = 0;o<tabElements.length;o++){
		if(tabElements[o].category == "umlOperation"){
			idParentM = tabElements[o].idParent;
				for(var k = 0;k<tabElements.length;k++){
					if(idParentM === tabElements[k].key){
						tabElements[k].operations.push(tabElements[o].finalParse());}}}}
}












