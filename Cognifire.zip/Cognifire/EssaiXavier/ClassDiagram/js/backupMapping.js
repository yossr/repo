function readJson(_IDArea){
	var val = document.getElementById(""+_IDArea).value;
	var res = jQuery.parseJSON(val);

	console.log(res);
	console.log(res.properties);
	console.log(res.properties.priority);
	console.log(res.mapping);
	getMapping(res);
	addRadios(res);
}

function addRadios(objJson){
	var para;
	var labl
	var keys = Object.keys(objJson.properties);
	var taille = Object.keys(objJson.properties).length;

	for(var compteur = 0; compteur<taille;compteur++){
		labl = document.createElement("label");
		para = document.createElement("input");
		labl.setAttribute("class","radio-inline");
		para.setAttribute("type","radio");
		para.setAttribute("id", keys[compteur]);
		para.setAttribute("name", "radio");
		para.setAttribute("onchange","callAddAssociateToProperty(this)");
		//para.addEventLister("change",function(event) {event.target})
		para.value = keys[compteur];
		labl.appendChild(para);
		labl.appendChild(document.createTextNode(keys[compteur]));
		document.getElementById("ligneRadio").appendChild(labl)

		
	}
}

function getMapping(objJson){

	filtre = ["backgroundColor","borderColor","lineColor","classNameColor","backgroundBrightness","borderBrightness","lineBrightness","borderSize","strokeLineSize","classNameSize","classNameUnderline","classOrientation"];
	tabFiltreAdded = [];

	cptBrightness = 0;


	tabProperties = [];
	for(var i = 0;i<Object.keys(objJson.properties).length;i++){
		tabProperties.push(Object.keys(objJson.properties)[i]);
		console.log(tabProperties);
	}

	for(var nbElem=0;nbElem<data.umlClasses.length;nbElem++){
		for(var nbPro=0;nbPro<data.umlClasses.length;nbPro++){
			if(data.umlClasses[nbElem].category == "umlClass"){
				data.umlClasses[nbElem][tabProperties[nbPro]]=0;
			}
		}
	}

	for(var j=0;j<objJson.mapping.length;j++){
		var currMap;
		var currProperty;
		var tabCurrProperty;
		currMap = objJson.mapping[j];
		console.log(currMap);
		currMapProperty = currMap.property;
		if(objJson.properties[currMap.property]) {
			var tabCurrProperty = objJson.properties[currMap.property];
			console.log(tabCurrProperty);
			var currProperty = currMap.property;
			filtreApp = currMap.implantation;
					if(filtreApp == filtre[0]){
						tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: tabColors[i]});
    					}
						BackgroundColor.choices[currMap.property] = {
							defaultValue: "white",
    						hueLevel: saturated,
    						table: tab
    							
    						
						}
						console.log("Ajout du filtre BackgroundColor pour " + currMapProperty);
						tabFiltreAdded.push(filtre[0]);
						BackgroundColor.associateToAProperty(currMap.property);
						console.log(BackgroundColor.choices[currMap.property].table);
					}
					else if(filtreApp == filtre[1]){
    					tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: tabColors[i]});
    					}
    						

						BorderColor.choices[currMap.property] = {
    						defaultValue: "black",    						
    						hueLevel: saturated,
    						table: tab
						}
						console.log("Ajout du filtre BorderColor pour " + currMapProperty);
						tabFiltreAdded.push(filtre[1]);
						BorderColor.associateToAProperty(currMap.property);
						console.log(BorderColor.choices[currMap.property].table);
					}
					else if(filtreApp == filtre[2]){
						tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: tabColors[i]});
    					}
						LineColor.choices[currMap.property] = {
							defaultValue: "black",
    						hueLevel: saturated,
    						table: tab
    						
						}
						tabFiltreAdded.push(filtre[2]);
						console.log("lineColor");
						LineColor.associateToAProperty(currMap.property);
					}
					else if(filtreApp == filtre[3]){
						tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: tabColors[i]});
    					}

						TextColor.choices[currMap.property] = {
							defaultValue: "black",
    						hueLevel: saturated,
    						table: tab
    							
    						
						}
						tabFiltreAdded.push(filtre[3]);
						TextColor.associateToAProperty(currMap.property);

					}
				

			
			
					else if(filtreApp == filtre[4]){
						tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: tabColors[cptBrightness], distance : tabHue[i]});
    					}
						Distance.choices[currMap.property] = {
							defaultValue: "white",
    						hueLevel: saturated,
    						table: tab
    						
						}
						tabFiltreAdded.push(filtre[4]);
						Distance.associateToAProperty(currMap.property);
						cptBrightness++;

					}
					else if(filtreApp == filtre[5]){
						tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: tabColors[cptBrightness], distance : tabHue[i]});
    					}
						BorderDistance.choices[currMap.property] = {
							defaultValue: "black",
    						hueLevel: saturated,
    						table: tab
    							
    						
						}
						tabFiltreAdded.push(filtre[5]);
						BorderDistance.associateToAProperty(currMap.property);
						cptBrightness++;
					}
					else if(filtreApp == filtre[6]){
						tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: tabColors[cptBrightness], distance : tabHue[i]});
    					}
						LineDistance.choices[currMap.property] = {
							defaultValue: "black",
    						hueLevel: saturated,
    						table: tab
    							
   						
    						
						}
						tabFiltreAdded.push(filtre[6]);
						LineDistance.associateToAProperty(currMap.property);
						cptBrightness++;
					}
					if(filtreApp == filtre[7]){
						tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: i});
    					}	
						StrokeSize.choices[currMap.property] = {
							defaultValue: 1,
    						table: tab
    					}
						console.log("Ajout du filtre StrokeSize pour " + currMapProperty);
						tabFiltreAdded.push(filtre[7]);
						StrokeSize.associateToAProperty(currMap.property);
					}
					else if(filtreApp == filtre[8]){
						tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: i});
    					}
						StrokeLineSize.choices[currMap.property] = {
							defaultValue: 1,
    						table: tab
    							
						}
						tabFiltreAdded.push(filtre[8]);
						StrokeLineSize.associateToAProperty(currMap.property);

					}
					else if(filtreApp == filtre[9]){ // Gestion erreur taille texte a faire
						tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: tabSizeText[i]});
    					}
						TextSize.choices[currMap.property] = {
    						defaultValue: "20px sans-serif",
    						table: tab
						}
						tabFiltreAdded.push(filtre[9]);
						TextSize.associateToAProperty(currMap.property);
					}
					
				
			
				else if(filtreApp == filtre[10]){
					tab = [];
    					for(var i =0;i<tabCurrProperty.length;i++){
    						if(i==0){
    							tab.push({threshold: tabCurrProperty[i], value: false});
    						}
    						else{tab.push({threshold: tabCurrProperty[i], value: true});}
    					}
						TextUnderLine.choices[currMap.property] = {  // A REVOIR SI PROBLEME
							defaultValue: false,
    						table: tab
    							
						}
						tabFiltreAdded.push(filtre[10]);
						TextUnderLine.associateToAProperty(currMap.property);

				}
				else if(filtreApp == filtre[11]){
					valAnglePossible = true;
					for(var i=0;i<tabCurrProperty.length;i++){
						if(tabCurrProperty[i] > 90){
							valAnglePossible = false;
						}
					}
					if(valAnglePossible){
						tab = [];
        				for(var i =0;i<tabCurrProperty.length;i++){
    						tab.push({threshold: tabCurrProperty[i], value: tabAngle[i]});
    					}
						Orientation.choices[currMap.property] = {
							defaultValue: 0,
    						table: tab
						}
						tabFiltreAdded.push(filtre[11]);
						Orientation.associateToAProperty(currMap.property);
					}
				}

				
			}
			addLegend(objJson);
		}
}
	


var cara;

function addLegend(file){
        var legend = document.getElementById("legend");
        var mapp = file.mapping;
        var prop = file.properties;
        var impl = ["backgroundColor","borderColor","lineColor","classNameColor", "backgroundBrightness","borderBrightness","lineBrightness", "borderSize","strokeLineSize","classNameSize", "classNameUnderline"
                                , "classOrientation"];

        for(var k = 0; k <file.mapping.length;k++){
                x = file.mapping[k];
                switch(x.implantation){
                        case impl[0] :
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[0]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[BackgroundColor.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[BackgroundColor.choices[x.property].table[i].value][BackgroundColor.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[1] :
                        	var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[1]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[BorderColor.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[BorderColor.choices[x.property].table[i].value][BorderColor.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[2]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[2]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[LineColor.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[LineColor.choices[x.property].table[i].value][LineColor.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        
                        case impl[3]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[3]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[TextColor.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[TextColor.choices[x.property].table[i].value][TextColor.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[4]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[4]));
                            legend.appendChild(p);
                            for (var i =  0; i<prop[x.property].length;i++){
                            	console.log(Distance.choices[x.property].table[i].value);
                                colorPalette = Colors.colorLevels[Distance.choices[x.property].table[i].value][Distance.choices[x.property].table[i].distance];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-border-stroke");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[5]:
							var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[5]));
                            legend.appendChild(p);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[BorderDistance.choices[x.property].table[i].value][BorderDistance.choices[x.property].table[i].distance];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;                        
                        case impl[6]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[6]));
                            legend.appendChild(p);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[LineDistance.choices[x.property].table[i].value][LineDistance.choices[x.property].table[i].distance];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[7]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[7]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-border-stroke");
                            caseDefault.style.border = "1px solid";
                            caseDefault.style.backgroundColor = Colors.colorLevels[StrokeSize.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[StrokeSize.choices[x.property].table[i].value][StrokeSize.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-border-stroke");
                                colorDiv.style.border = "solid "+i+"px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[8]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[8]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-line-stroke");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[StrokeLineSize.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[StrokeLineSize.choices[x.property].table[i].value][StrokeLineSize.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-line-stroke");
                                colorDiv.style.border = "solid "+i+"px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[9]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[9]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[TextSize.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[TextSize.choices[x.property].table[i].value];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[10]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[10]));
                            legend.appendChild(p);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[TextUnderLine.choices[x.property].table[i].value];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[11]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[11]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[Orientation.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[Orientation.choices[x.property].table[i].value];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                }
        }

}
