// Fonctions nécessaires pour le mapping perso
function addPropertiesToObjects(objJson){
	tabProperties = [];

    for(var i = 0;i<Object.keys(objJson.properties).length;i++){
        tabProperties.push(Object.keys(objJson.properties)[i]);
        console.log(tabProperties);
    }
    for(var nbElem=0;nbElem<data.umlClasses.length;nbElem++){
        for(var nbPro=0;nbPro<data.umlClasses.length;nbPro++){
            if(data.umlClasses[nbElem].category == "umlClass"){
                data.umlClasses[nbElem][tabProperties[nbPro]]=0;
            }
        }
    }
}

function isThisFilterExisting(filterToApp){
	filtre = ["backgroundColor","borderColor","lineColor","classNameColor","backgroundBrightness","borderBrightness","lineBrightness","borderSize","strokeLineSize","classNameSize","classNameUnderline","classOrientation"];
	exist = filtre.indexOf(filterToApp)
	return exist;
}

function isThisPropertyExistInProperties(currMapp,properties){
	exist = properties[currMapp.property];
	return exist;
}

function getFilterIndex(filterToApp){
	var tabObjsFiltre = ["BackgroundColor","BorderColor","LineColor","TextColor","Distance","BorderDistance","LineDistance","StrokeSize","StrokeLineSize","TextSize","TextUnderLine","Orientation"];
	index = tabObjsFiltre.indexOf(filterToApp);
	return index;
}
function getFilterWithIndex(index){
	var tabObjsFiltre = ["BackgroundColor","BorderColor","LineColor","TextColor","Distance","BorderDistance","LineDistance","StrokeSize","StrokeLineSize","TextSize","TextUnderLine","Orientation"];
	return tabObjsFiltre[index];
}
function getFilter(filterToApp){
	index = isThisFilterExisting(filterToApp);
	ret = getFilterWithIndex(index);
	return ret;
}

function incrementeCptBrightness(i){
	if(i==4 || i==5 || i==6){
		document.cptBrightness++;
	}
}


function getValueFromTab(i,tab){
	ret = 0;
	if(!(tab)){
		ret = i;
	}
	else{
		if(tab == -1){
			ret = i;
		}
		else{
			ret = tab[i];
		}
	}
	console.log(ret);
	return ret;
}

function getTabThresholdTab(tabCurrProperty){
	return [tabCurrProperty,tabCurrProperty,tabCurrProperty,tabCurrProperty,tabCurrProperty,tabCurrProperty,tabCurrProperty,tabCurrProperty,tabCurrProperty,tabCurrProperty,tabCurrProperty,tabCurrProperty];
}

function getTabThresholdI(i){
	return [i,i,i,i,i,i,i,i,i,i,i,i];
}

function getTabValueTab(tabColors,tabTextSize,tabAngle,tabUnderline){
	return [tabColors,tabColors,tabColors,tabColors,tabColors,tabColors,tabColors,-1,-1,tabTextSize,tabUnderline,tabAngle];
}

function getTabValueI(i){
	cpt = document.cptBrightness;
	return [i,i,i,i,cpt,cpt,cpt,i,i,i,i,i];
}

function getTabDistanceTab(tabDistance){
	return [-1,-1,-1,-1,tabDistance,tabDistance,tabDistance,-1,-1,-1,-1,-1];
}

function getTabDistanceI(i){
	return [saturated,saturated,saturated,saturated,i,i,i,saturated,saturated,saturated,saturated,saturated];
}

function getTabHueLevelTab(tabHue){
	return [-1,-1,-1,-1,tabHue,tabHue,tabHue,-1,-1,-1,-1,-1];
}

function getTabHueLevelI(saturated,i){
	return [saturated,saturated,saturated,saturated,i,i,i,saturated,saturated,saturated,saturated,saturated];
}
function getTabBgColorTab(tabColors){
	return [tabColors,-1,-1,-1,tabColors,-1,-1,-1,-1,-1,-1,-1];
}
function getTabBgColorI(i){
	cpt = document.cptBrightness;
	return [i,7,7,7,cpt,7,7,7,7,7,7,7];
}
function getTabBorderColorTab(tabColors){
	return [-1,tabColors,-1,-1,-1,tabColors,-1,-1,-1,-1,-1,-1];
}
function getTabBorderColorI(i){
	cpt = document.cptBrightness;
	return [6,i,6,6,6,cpt,6,6,6,6,6,6];
}
function getTabLineColorTab(tabColors){
	return [-1,-1,tabColors,-1,-1,-1,tabColors,-1,-1,-1,-1,-1];
}
function getTabLineColorI(i){
	cpt = document.cptBrightness;
	return [6,6,i,6,6,6,cpt,6,6,6,6,6];
}
function getTabTextColorTab(tabColors){
	return [-1,-1,-1,tabColors,-1,-1,-1,-1,-1,-1,-1,-1];
}
function getTabTextColorI(i){
	return [6,6,6,i,6,6,6,6,6,6,6,6];
}
function getTabStrokeSize(i){
	return [1,1,1,1,1,1,1,i,1,1,1,1];
}
function getTabStrokeLineSize(i){
	return [1,1,1,1,1,1,1,1,i,1,1,1];
}
function getTabTextSizeTab(tabText){
	return [-1,-1,-1,-1,-1,-1,-1,-1,-1,tabText,-1,-1];
}
function getTabTextSizeI(str,i){
	return [str,str,str,str,str,str,str,str,str,i,str,str];
}
function getTabAngleTab(tabAngle){
	return [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,tabAngle];
}
function getTabAngleI(i){
	return [0,0,0,0,0,0,0,0,0,0,0,i];
}
function getTabUnderline(i){
	mod = i%2;
	if(mod==0){
		ret = [false,false,false,false,false,false,false,false,false,false,false,false];
	}
	else{
		ret = [false,false,false,false,false,false,false,false,false,false,true,false];
	}
	return ret;
}
function getTabDefault(){
	return ["white","black","black","black","white","black","black",1,1,"20px sans-serif",false,0];
}

function getTextPrompt(){
	return ["hidden","hidden","hidden","visible","hidden","hidden","hidden","hidden","hidden","visible","visible","hidden"];
}

function getLinePrompt(){
	return ["hidden","hidden","visible","hidden","hidden","hidden","visible","hidden","visible","hidden","hidden","hidden"];
}