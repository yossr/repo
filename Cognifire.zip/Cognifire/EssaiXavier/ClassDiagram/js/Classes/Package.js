class Package{
	constructor(id,name,idParent){
		this.key = id;
		this.name = name;
		this.group = idParent;
		this.category = "umlPackage";
		this.idEnfant = [];
	}

	finalParse(){
		if(this.group == 0){
			return {
				key : this.key, 
				name : this.name, 
				isGroup : true,
			};
		}
		else{
			return {
				key : this.key, 
				name : this.name, 
				isGroup : true,
				group : this.group
			};		
		}	
	}

}