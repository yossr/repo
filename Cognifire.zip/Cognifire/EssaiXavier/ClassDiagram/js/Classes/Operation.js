class Operation{
	constructor(key, name, idParent){
		this.key = key;
		this.name = name;
		this.idParent = idParent;
		this.params = [];
		this.category = "umlOperation";
	}

	finalParse(){
		return {
			name : this.name,
			parameters : this.params,
		}
	}

	addParam(name,type){
		this.params.push({name: name, type: type});
	}

	
}