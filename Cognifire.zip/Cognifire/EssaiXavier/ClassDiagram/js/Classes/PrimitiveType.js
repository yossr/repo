class PrimitiveType {
	constructor(category,id,name){
		this.category = category;
		this.id = id;
		this.name = name;
	}
}