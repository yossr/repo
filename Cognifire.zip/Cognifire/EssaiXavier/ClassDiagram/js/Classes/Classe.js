class Classe{
	constructor(key,name,idParent,visibility){
		this.key = key;
		this.name = name;
		this.idParent = idParent;
		this.visibility = visibility;
		this.category = "umlClass";
		this.color = "white";
		this.backgroundColor = 7;
		this.borderColor = 6;
		this.lineColor = 6;
		this.classNameColor = 6;
		this.borderSize = 1;
		this.lineSize = 1;
		this.textSize = "20px sans-serif";
		this.textColor = 6;
		this.angle = 0;
		this.attributes = [];
		this.operations = [];
		this.group = "";
	}

	setGroup(group){
		this.group = group;
	}

	finalParse(){
		if(this.group == ""){
			return {
				key : this.key, 
				name : this.name, 
				color : this.color,
				category : this.category,
				taille : 1,
				attributes : this.attributes,
				operations : this.operations

			};  // return dictionnaire
		}
		else{
			return {
				key : this.key, 
				name : this.name, 
				color : this.color,
				category : this.category,
				taille : 1,
				attributes : this.attributes,
				operations : this.operations,
				group : this.group
			}	
		}
	}

}