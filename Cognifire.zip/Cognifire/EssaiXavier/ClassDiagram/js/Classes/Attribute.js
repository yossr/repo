class Attribute{
	constructor(key, name,idParent,visibility,type){
		this.key = key;
		this.name = name;
		this.idParent = idParent;
		this.type = type;
		this.visibility = visibility;
		this.category = "umlAttribute";
	}

	setType(type){
		this.type = type;
	}

	finalParse(){
		return {
			name : this.name,
			type : this.type,
			visibility : this.visibility
		}
	}
}