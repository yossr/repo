/**
 * Created by lepallex on 10/02/15.
 */


LineColor = {

    associateToAProperty: function (property) {
        var realTable = [];
        console.log(property);
        var choices = this.choices[property];
        var table = choices.table;
        for (var i = 0; i < table.length; i++){
            realTable[i] = {threshold: table[i].threshold, value: Colors.colorLevels[table[i].value][choices.hueLevel]};
        }
        UmlClassStrategy.lineColor = DecorateDiagram.createFunctionForThresholdValues(property, realTable, choices.defaultValue);
        DecorateDiagram.updateDiagramTemplates();
    },

    addLineColorInLegend: function (property, table, defaultValue) {
        var legend = document.getElementById("legend");
        var rajout = domHelp.addElement(legend, "div");

        var intitule = domHelp.addElement(rajout, "div", "class", "intitule");
        domHelp.addText(intitule, property + " >> Line Color");

        function ajoutCase(color, value) {
            var _case = domHelp.addElement(rajout, "div", "class", "enLigne");
            carre = domHelp.addElement(_case, "span", "class", "border");
            domHelp.addElement(_case, "BR");
            domHelp.addText(_case, value);
            carre.style.borderBottomColor = color;
        }

        ajoutCase(defaultValue, "null");
        for (var i = 0; i < table.length; i++) {
            ajoutCase(table[i].value, table[i].threshold);
        }
    },

    choices: {}
}


Filtre.LineColor = LineColor;