/**
 * Created by lepallex on 10/02/15.
 */


Orientation = {

    associateToAProperty: function (property) {
        var realTable = [];
        console.log(debut);
        var choices = this.choices[property];
        var table = choices.table;
        for (var i = 0; i < table.length; i++)
            realTable[i] = {threshold: table[i].threshold, value: table[i].value};
        console.log(UmlClassStrategy);
        UmlClassStrategy.angle = DecorateDiagram.createFunctionForThresholdValues(property, realTable, choices.defaultValue);
        DecorateDiagram.updateDiagramTemplates();
    },

    addOrientationInLegend: function (property, table, defaultValue) {
        var legend = document.getElementById("legend");
        var rajout = domHelp.addElement(legend, "div");

       var intitule = domHelp.addElement(rajout, "div", "class", "intitule");
       domHelp.addText(intitule, property + " >> Angle");

        function ajoutCase(angle, value) {
            var _case = domHelp.addElement(rajout, "div", "class", "enLigne");
            carre = domHelp.addElement(_case, "span", "class", "orientation");
            domHelp.addElement(_case, "BR");
            domHelp.addText(_case, value);
            carre.style.WebkitTransform="rotate("+angle+"deg)";
            console.log(carre.style.transform);
        }

        ajoutCase(0, "null");
        for (var i = 0; i < table.length; i++) {
            ajoutCase(table[i].value, table[i].threshold);
        }
    },

    choices: {}
}

Filtre.Orientation = Orientation;