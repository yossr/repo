/**
 * Created by lepallex on 10/02/15.
 */

DecorateDiagram = {
    valueByThreshold: function (object) {
        var value = this.defaultValue;
        var typeThreshold = typeof(this.table[0].threshold);

        if(typeof(this.table[0].threshold) == "number"){

            for (var i = 0; i < this.table.length; i++) {
                if (object[this.property]>= this.table[i].threshold){
                    value = this.table[i].value;
                }
            }
        }

        else if(typeof(this.table[0].threshold) == "string"){
            console.log("type string");
            for(var i =0;i<this.table.length;i++){
                if(this.table[i].threshold == object[this.property]){
                    value = this.table[i].value;
                }
            }
            
        }

        return value;
        
    },

    createFunctionForThresholdValues: function (property, table, defaultValue) {
        return this.valueByThreshold.bind({property: property, table: table, defaultValue: defaultValue});
    },


    updateDiagramTemplates: function () {
        diagram.startTransaction("templates changes");
        templatesMap = templatesMap.copy();
        diagram.nodeTemplateMap = templatesMap;
        diagram.commitTransaction("templates changes");
    }

}