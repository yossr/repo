function createHTMLDivForCurrentProperty(i,mapping,filter){
	var p = document.createElement("h6");
    p.appendChild(document.createTextNode(mapping[i].property + " >> " + filter));
    legend.appendChild(p);
    var gdDiv = document.createElement("div");
    gdDiv.setAttribute("class", "legendContainer");
    legend.appendChild(gdDiv);
    return gdDiv;
}

function createDIVForEachValueInCurrentProperty(i,mapping,filter,index,properties,gdDiv){
	var colorDiv;
	console.log(mapping[i].property);
	console.log(filter);
	console.log(Filtre)
	console.log(properties[mapping[i].property].length);
	for(var j=0;j<properties[mapping[i].property].length;j++){
		currPropertyValue = properties[mapping[i].property][j];
		currProperty = mapping[i].property;
		filterTable = Filtre[filter].choices[mapping[i].property].table[j];
		colorDiv = document.createElement("div");
		colorDiv.setAttribute("class",getClassCSS(index));
		colorDiv = applyAllCSS(colorDiv,filterTable,currPropertyValue,currProperty);
		divCasePlusPropertyValue = createDivCasePlusPropertyValue(colorDiv, currPropertyValue);
			gdDiv.appendChild(divCasePlusPropertyValue);
	}
}

function createDivCasePlusPropertyValue(colorDiv, currPropertyValue){
	var div = document.createElement("div");
	div.setAttribute("class","divCasePlusPropertyValue");
	var lbl = document.createTextNode(currPropertyValue);
	div.appendChild(colorDiv);
	div.appendChild(lbl);
	return div;
}

function getClassCSS(index){
	var tabClassCSS = ["class-bg-color","class-bg-color","class-bg-color","class-classNameColor","class-bg-color","class-bg-color","class-bg-color","class-bg-color","class-bg-color","class-classNameSize","class-classUnderline","class-bg-color"];
	return tabClassCSS[index];
}

function applyAllCSS(colorDiv,filterTable,property,filter){
	console.log(filterTable);
	colorDiv.style.background = getBackgroundColor(filterTable);
	colorDiv.style.borderColor = getBorderColor(filterTable);
	textDiv = createTextDiv(filterTable);
	lineDiv = createLineDiv(filterTable);
	colorDiv.appendChild(textDiv);
	colorDiv.style.borderWidth = getBorderSize(filterTable);
	colorDiv.style.WebkitTransform = getAngle(filterTable); // A voir différent types de rotate
	colorDiv.appendChild(textDiv);
	colorDiv.appendChild(lineDiv);
	createOnClickFunction(textDiv,currPropertyValue,filter);
	createOnClickFunction(lineDiv,currPropertyValue,filter);
	createOnClickFunction(colorDiv,currPropertyValue,filter);



	return colorDiv;

}

function getBackgroundColor(filterTable){
	console.log(filterTable);
	return Colors.colorLevels[filterTable.bgColor][filterTable.hueLevel];
}

function getBorderColor(filterTable){
	return Colors.colorLevels[filterTable.borderColor][filterTable.hueLevel];
}

function getBorderSize(filterTable){
	console.log(filterTable);
	return filterTable.borderSize + "px";
}

function getAngle(filterTable){
	return "rotate("+filterTable.angle+"deg)"
}

function createTextDiv(filterTable){
	var textDiv = document.createElement("div");
	textDiv.setAttribute("class","classTextDiv"); //A définir dans le CSS
	textDiv.innerHTML = "nameClass";
	textDiv.style.color = getTextColor(filterTable);
	textDiv.style.font = getTextSize(filterTable);
	textDiv.style.textDecoration = getTextUnderline(filterTable);
	textDiv.style.visibility = getTextVisibility(filterTable);
	return textDiv;
}

function getTextColor(filterTable){
	return Colors.colorLevels[filterTable.textColor][filterTable.hueLevel];
}

function getTextSize(filterTable){
	return filterTable.textSize;
}

function getTextUnderline(filterTable){
	val = filterTable.underline;
	if(val == true){
		ret = "underline";
	}
	else{
		ret = "none"
	}
	return ret;
}

function getTextVisibility(filterTable){
	return filterTable.showText;
}

function createLineDiv(filterTable){
	var lineDiv = document.createElement("div");
	lineDiv.setAttribute("class","classLineDiv");
	lineDiv.style.borderTop = "solid "+ getLineSize(filterTable) + "px " + getLineColor(filterTable);
	lineDiv.style.visibility = getLineVisibility(filterTable);
	return lineDiv;
}

function getLineSize(filterTable){
	return filterTable.lineSize;
}

function getLineColor(filterTable){
	return Colors.colorLevels[filterTable.lineColor][filterTable.hueLevel]
}

function getLineVisibility(filterTable){
	return filterTable.showLine;
}

function createOnClickFunction(div,currPropertyValue,filter){
	div.addEventListener("click",function(e){

		

		cara = currPropertyValue;
		criteria = filter;
		var formerSelectedCase = document.getElementById("selected");
		if(formerSelectedCase!= null || formerSelectedCase!= undefined){
			formerSelectedCase.removeAttribute("id");
			e.target.setAttribute("id", "selected");
		}
		applyToSelectedParts(criteria,cara);
		DecorateDiagram.updateDiagramTemplates();
	})
}

function applyToSelectedParts(criteria,cara){
        diagram.selection.each(function(n) {
        	console.log(n.data)
            n.data[criteria] = cara;
        });
}
