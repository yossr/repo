

function setLocalStorageMapping(mapping){
    localStorage.setItem('histoMapping',mapping);
}

function geneHistoMapping(){
    if('histoMapping' in localStorage){
        console.log("yo");
        var histoMappingRecup = localStorage.getItem('histoMapping');
        histoMappingRecup = jQuery.parseJSON(histoMappingRecup);
        getMapping(histoMappingRecup);
    }
}


function readJson(_IDArea){
	var val = document.getElementById(""+_IDArea).value;

	var res = jQuery.parseJSON(val);
    setLocalStorageMapping(val);
	getMapping(res);
}

function butSelectionClasse(){
	criteria = "selection";
	console.log(criteria);
}

function getMapping(objJson){
	tabFiltreAdded = [];
    document.cptBrightness = 0;
    var properties = objJson.properties;
    var implantation = objJson.mapping;
    var currMapping;
    var currProperty;
    var indexCurrProperty;
    var filterToApp;
    var tabFiltre = [];
    addPropertiesToObjects(objJson);
    for(var indexCurrMapping=0;indexCurrMapping<implantation.length;indexCurrMapping++){
        currMapping = implantation[indexCurrMapping];
        filterToApp = currMapping.implantation;
        indexFilter = isThisFilterExisting(filterToApp);
        propertyExist = isThisPropertyExistInProperties(currMapping,properties);
        console.log(filterToApp)
        if(!(indexFilter==-1) && !(propertyExist==-1)){
            tabCurrProperty = propertyExist;
            tabObj = [];
            for(var indexTabProperty=0;indexTabProperty<tabCurrProperty.length;indexTabProperty++){
                tabThresholdTab = getTabThresholdTab(tabCurrProperty);
                tabThresholdI = getTabThresholdI(indexTabProperty);
                tabValueTab = getTabValueTab(tabColors,tabSizeText,tabAngle,tabUnderlined);
                tabValueI = getTabValueI(indexTabProperty);
                tabDistanceTab = getTabHueLevelTab(tabHue);
                tabDistanceI = getTabHueLevelI(saturated,indexTabProperty);
                tabHueLevelTab = getTabHueLevelTab(tabHue);
                tabHueLevelI = getTabHueLevelI(saturated,indexTabProperty);
                tabBgColorsTab = getTabBgColorTab(tabColors);
                tabBgColorsI = getTabBgColorI(indexTabProperty);
                tabBorderColorTab = getTabBorderColorTab(tabColors);
                tabBorderColorI = getTabBorderColorI(indexTabProperty);
                tabLineColorTab = getTabLineColorTab(tabColors);
                tabLineColorI = getTabLineColorI(indexTabProperty);
                tabTextColorTab = getTabTextColorTab(tabColors);
                tabTextColorI = getTabTextColorI(indexTabProperty);
                tabStrokeSize = getTabStrokeSize(indexTabProperty);
                tabStrokeLineSize = getTabStrokeLineSize(indexTabProperty);
                tabTextSizeTab = getTabTextSizeTab(tabSizeText);
                tabTextSizeI = getTabTextSizeI("20px sans-serif",indexTabProperty);
                tabUnderline = getTabUnderline(indexTabProperty);
                tabAngleTab = getTabAngleTab(tabAngle);
                tabAngleI = getTabAngleI(indexTabProperty);
                tabDefault = getTabDefault();
                tabTextPrompt = getTextPrompt();
                tabLinePrompt = getLinePrompt();
                console.log(tabThresholdI);
                console.log(tabThresholdTab);
                console.log(getValueFromTab(tabThresholdI[indexFilter],tabThresholdTab[indexFilter]));
                tabObj.push({
                    threshold : getValueFromTab(tabThresholdI[indexFilter],tabThresholdTab[indexFilter]),
                    value : getValueFromTab(tabValueI[indexFilter],tabValueTab[indexFilter]),
                    distance : getValueFromTab(tabDistanceI[indexFilter],tabDistanceTab[indexFilter]),
                    hueLevel : getValueFromTab(tabHueLevelI[indexFilter],tabHueLevelTab[indexFilter]),
                    bgColor : getValueFromTab(tabBgColorsI[indexFilter],tabBgColorsTab[indexFilter]),
                    borderColor : getValueFromTab(tabBorderColorI[indexFilter],tabBorderColorTab[indexFilter]),
                    lineColor : getValueFromTab(tabLineColorI[indexFilter],tabLineColorTab[indexFilter]),
                    textColor : getValueFromTab(tabTextColorI[indexFilter],tabTextColorTab[indexFilter]),
                    borderSize : getValueFromTab(tabStrokeSize[indexFilter]),
                    lineSize : getValueFromTab(tabStrokeLineSize[indexFilter]),
                    textSize : getValueFromTab(tabTextSizeI[indexFilter],tabTextSizeTab[indexFilter]),
                    angle : getValueFromTab(tabAngleI[indexFilter],tabAngleTab[indexFilter]),
                    underline : getValueFromTab(tabUnderline[indexFilter]),
                    showText : getValueFromTab(indexFilter,tabTextPrompt),
                    showLine : getValueFromTab(indexFilter,tabLinePrompt)

                });

                Filtre[getFilterWithIndex(indexFilter)].choices[implantation[indexCurrMapping].property] = {
                    defaultValue : getValueFromTab(indexFilter,tabDefault),
                    hueLevel : saturated,
                    table : tabObj
                }
            }
            incrementeCptBrightness(indexFilter);
            console.log(document.cptBrightness)
            console.log(Filtre[getFilterWithIndex(indexFilter)]);
            Filtre[getFilterWithIndex(indexFilter)].associateToAProperty(implantation[indexCurrMapping].property);
            tabFiltre.push(getFilterWithIndex(indexFilter));
            console.log(tabFiltre);
            console.log(Filtre[getFilterWithIndex(indexFilter)]);
        }
        else if(indexFilter == -1){
            console.log("error : l'implantation utilisée n'est pas supportée");
        }
        else if(propertyExist == -1){
            console.log("error : la property utilisée dans mapping n'existe pas dans properties");
        }
    }
	addLegend(objJson);
}

function addLegend(file){
    mapping = file.mapping;
    properties = file.properties;
    legend = document.getElementById("legend");
    for (var i = 0;i < mapping.length; i++) {
        console.log(mapping[i])
        index = isThisFilterExisting(mapping[i].implantation);
        filter = getFilterWithIndex(index);
        gdDiv = createHTMLDivForCurrentProperty(i,mapping,filter);
        createDIVForEachValueInCurrentProperty(i,mapping,filter,index,properties,gdDiv);
    }
}	

/*
var cara;

function addLegend(file){
    var legend = document.getElementById("legend");
    var mapp = file.mapping;
    var prop = file.properties;
    var impl = ["backgroundColor","borderColor","lineColor","classNameColor", "backgroundBrightness","borderBrightness","lineBrightness", "borderSize","strokeLineSize","classNameSize", "classNameUnderline","classOrientation"];
    var tabObjsFiltre = ["BackgroundColor","BorderColor","LineColor","TextColor","Distance","BorderDistance","LineDistance","StrokeSize","StrokeLineSize","TextSize","TextUnderLine","Orientation"];
    var tabClassCSS = ["class-bg-color","class-bg-color","class-line-stroke","class-classNameColor","class-bg-color","class-bg-color","class-bg-color","class-bg-color","class-bg-color","class-classNameSize","class-classUnderline","class-bg-color"];
    var tabColorsSecond = ["[BackgroundColor.choices[b.property].hueLevel]","[BorderColor.choices[x.property].hueLevel]","hueLevels","hueLevels","distance","distance","distance","hueLevels","hueLevels",""]


    for(var a = 0;a<file.mapping.length; a++){
        b = file.mapping[a];
        indexB = impl.indexOf(b.implantation); 
        //Création dans la légende
        var colorDiv;                                
        var p = document.createElement("h1");
        p.appendChild(document.createTextNode(file.mapping[a].property + " >> " + impl[indexB]));
        legend.appendChild(p);
        var gdDiv = document.createElement("div");
        gdDiv.setAttribute("class", "legendContainer");
        legend.appendChild(gdDiv);
        for (var c=0;c<prop[b.property].length;c++){
            filtreTable = Filtre[tabObjsFiltre[indexB]].choices[b.property].table[c];
            colorPalette = Colors.colorLevels[filtreTable.color1][filtreTable.hueLevel];
            colorDiv = document.createElement("div");
            colorDiv.setAttribute("class", tabClassCSS[indexB]);
            colorDiv.style.backgroundColor = colorPalette;
            colorDiv.style.borderColor = Colors.colorLevels[filtreTable.borderColor][filtreTable.hueLevel];
            colorDiv.style.borderWidth = filtreTable.borderSize + "px";
            colorDiv.cara = prop[b.property][c];
            colorDiv.proper = b.property;
            colorDiv.onclick = function(e){
                cara = e.target.cara;
                criteria = e.target.proper ; 
                jQuery(".legendContainer .classNameUnderline, .class-bg-color, .class-classUnderline").css("box-shadow", "none");
                e.target.style.boxShadow = "10px 10px 5px #aaaaaa";
            };
            if(indexB==11){
                colorDiv.style.WebkitTransform = "rotate("+filtreTable.value+"deg)";
            }
            var container = document.createElement("div");
            var lblText = document.createTextNode(prop[b.property][c]);
            var lbl = document.createElement("p");
            lbl.appendChild(lblText);
            container.appendChild(colorDiv);
            container.appendChild(lbl);
            container.setAttribute("class", "legendItemContainer");
            gdDiv.appendChild(container);

            if(indexB == 10 || indexB == 9 || indexB == 3){
                colorDiv.setAttribute("class", "classUnderline-p");
                var text = document.createTextNode("nameClass");
                colorDiv.appendChild(text);
                colorDiv.style.font = filtreTable.textSize;
                colorDiv.style.color = Colors.colorLevels[filtreTable.textColor][filtreTable.hueLevel];
                colorDiv.style.marginBottom = "5px";
                if(c == 1 && indexB == 10){
                        colorDiv.style.textDecoration = "underline";
                }
            }
            if(indexB == 2 || indexB == 6 || indexB == 8){
                ligneDiv = document.createElement("div");
                ligneDiv.setAttribute("class","ligneColor-div");
                ligneDiv.style.borderBottom = "solid "+ filtreTable.lineSize + "px " + Colors.colorLevels[filtreTable.lineColor][filtreTable.hueLevel];
                colorDiv.style.border = "none";
                colorDiv.appendChild(ligneDiv);
            }

                }
        }

}




/*
        for(var k = 0; k <file.mapping.length;k++){
                x = file.mapping[k];
                switch(x.implantation){
                        case impl[0] :
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[0]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[BackgroundColor.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[BackgroundColor.choices[x.property].table[i].value][BackgroundColor.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[1] :
                        	var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[1]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[BorderColor.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[BorderColor.choices[x.property].table[i].value][BorderColor.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[2]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[2]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[LineColor.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[LineColor.choices[x.property].table[i].value][LineColor.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        
                        case impl[3]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[3]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[TextColor.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[TextColor.choices[x.property].table[i].value][TextColor.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[4]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[4]));
                            legend.appendChild(p);
                            for (var i =  0; i<prop[x.property].length;i++){
                            	console.log(Distance.choices[x.property].table[i].value);
                                colorPalette = Colors.colorLevels[Distance.choices[x.property].table[i].value][Distance.choices[x.property].table[i].distance];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-border-stroke");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[5]:
							var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[5]));
                            legend.appendChild(p);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[BorderDistance.choices[x.property].table[i].value][BorderDistance.choices[x.property].table[i].distance];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;                        
                        case impl[6]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[6]));
                            legend.appendChild(p);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[LineDistance.choices[x.property].table[i].value][LineDistance.choices[x.property].table[i].distance];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[7]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[7]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-border-stroke");
                            caseDefault.style.border = "1px solid";
                            caseDefault.style.backgroundColor = Colors.colorLevels[StrokeSize.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[StrokeSize.choices[x.property].table[i].value][StrokeSize.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-border-stroke");
                                colorDiv.style.border = "solid "+i+"px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[8]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[8]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-line-stroke");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[StrokeLineSize.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[StrokeLineSize.choices[x.property].table[i].value][StrokeLineSize.choices[x.property].hueLevel];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-line-stroke");
                                colorDiv.style.border = "solid "+i+"px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[9]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[9]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[TextSize.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[TextSize.choices[x.property].table[i].value];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[10]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[10]));
                            legend.appendChild(p);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[TextUnderLine.choices[x.property].table[i].value];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                console.log(colorPalette);
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                        case impl[11]:
                            var colorDiv;                                
							var p = document.createElement("h1");
                            p.appendChild(document.createTextNode(x.property + " >> " + impl[11]));
                            legend.appendChild(p);
                            //Case valeur défaut
                            var caseDefault;
                            caseDefault= document.createElement("div");
                            caseDefault.setAttribute("class", "class-bg-color");
                            caseDefault.style.border = "solid 1px black";
                            caseDefault.style.backgroundColor = Colors.colorLevels[Orientation.choices[x.property].defaultValue];
                            caseDefault.style.display = "inline-block";
                            caseDefault.cara = 0;
                            caseDefault.proper = x.property;
                            caseDefault.onclick = function(e){
         	                    cara = e.target.cara;
                                criteria = e.target.proper ;
                                console.log(cara);
                                console.log(criteria);
                            };
                            legend.appendChild(caseDefault);
                            for (var i =  0; i<prop[x.property].length;i++){
                                colorPalette = Colors.colorLevels[Orientation.choices[x.property].table[i].value];
                                color = tabColors[i];
                                colorDiv= document.createElement("div");
                                colorDiv.setAttribute("class", "class-bg-color");
                                colorDiv.style.border = "solid 1px black";
                                colorDiv.style.backgroundColor = colorPalette;
                                colorDiv.style.display = "inline-block";
                                colorDiv.cara = prop[x.property][i];
                                colorDiv.proper = x.property;
                                colorDiv.onclick = function(e){
                                    cara = e.target.cara;
                                    criteria = e.target.proper ;
                                    console.log(cara);
                                    console.log(criteria);
                                };
                                legend.appendChild(colorDiv);
                            }
                            break;
                }
        }*/